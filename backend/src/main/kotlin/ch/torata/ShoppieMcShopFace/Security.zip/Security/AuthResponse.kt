package ch.torata.ShoppieMcShopFace.Security

import lombok.AllArgsConstructor
import lombok.Getter
import lombok.NoArgsConstructor
import lombok.Setter

data class AuthResponse(
    val username: String? = null,
    val accessToken: String? = null
)