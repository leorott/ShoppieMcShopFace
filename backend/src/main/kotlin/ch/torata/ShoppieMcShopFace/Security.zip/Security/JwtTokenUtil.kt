package ch.torata.ShoppieMcShopFace.Security

import io.jsonwebtoken.Claims
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.springframework.beans.factory.annotation.Value
import org.springframework.security.core.userdetails.User
import org.springframework.stereotype.Component
import java.util.*


@Component
class JwtTokenUtil {
    @Value("\${app.jwt.secret}")
    private val SECRET_KEY: String? = null

    fun generateAccessToken(user: User): String {
        return Jwts.builder()
            .setSubject(user.username)
            .setIssuer("PC WebShop")
            .setIssuedAt(Date())
            .setExpiration(Date(System.currentTimeMillis() + EXPIRE_DURATION))
            .signWith(SignatureAlgorithm.HS512, SECRET_KEY)
            .compact()
    }

    fun validateAccessToken(token: String?): Boolean {
        try {
            Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token)
            return true
        } catch (ex: RuntimeException) {
            return false
        }
    }

    fun getSubject(token: String): String {
        return parseClaims(token).subject
    }

    private fun parseClaims(token: String): Claims {
        return Jwts.parser()
            .setSigningKey(SECRET_KEY)
            .parseClaimsJws(token)
            .body
    }

    companion object {
        private const val EXPIRE_DURATION = (24 * 60 * 60 * 1000 // 24 hour
                ).toLong()
    }
}