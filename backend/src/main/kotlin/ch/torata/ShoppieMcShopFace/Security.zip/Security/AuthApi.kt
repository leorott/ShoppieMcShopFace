package ch.torata.ShoppieMcShopFace.Security

import jakarta.validation.Valid
import lombok.AllArgsConstructor
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.authentication.AuthenticationManager
import org.springframework.security.authentication.BadCredentialsException
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.userdetails.User
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController

@RestController
@AllArgsConstructor
class AuthApi {
    var authManager: AuthenticationManager? = null
    var jwtUtil: JwtTokenUtil? = null

    @PostMapping("/login")
    fun login(@RequestBody @Valid request: AuthRequest): ResponseEntity<*> {
        try {
            val authentication = authManager!!.authenticate(
                UsernamePasswordAuthenticationToken(
                    request.username, request.password
                )
            )

            val user = authentication.principal as User
            val accessToken: String = jwtUtil?.generateAccessToken(user) ?: ""
            val response: AuthResponse = AuthResponse(user.username, accessToken)

            return ResponseEntity.ok().body<Any>(response)
        } catch (ex: BadCredentialsException) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build<Any>()
        }
    }
}